-- vallee_des_roses mod
-- Version - v1.0

-- Cottage Style Glass
minetest.register_node("vallee_des_roses:cottage_sytle_glass", {
    description = "Cottage Sytle Glass",
    drawtype = "glasslike",
    tiles = {"vallee_des_roses_cottageglass.png"},
    paramtype = "light",
    is_ground_content = false,
    sunlight_propagates = true,
    sounds = default.node_sound_glass_defaults(),
    groups = {cracky=3,oddly_breakable_by_hand=3},
})

-- Marigold Flower
minetest.register_node("vallee_des_roses:marigold", {
    description = "A Marigold Flower",
    drawtype = "plantlike",

    -- Only one texture used
    tiles = {"vallee_des_roses_marigold.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -6 / 16, 6 / 16, 0.5, 6 / 16},
    },
    groups = {snappy=3,oddly_breakable_by_hand=3},
    walkable = false,
	buildable_to = true,
})

-- Buttercup Flower
minetest.register_node("vallee_des_roses:buttercup", {
    description = "A Buttercup Flower",
    drawtype = "plantlike",
    -- Only one texture used
    tiles = {"vallee_des_roses_buttercup.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, -1 / 16, 4 / 16},
    },
    groups = {snappy=3,oddly_breakable_by_hand=3},
    walkable = false,
	buildable_to = true,
})

-- Brittle Poppy
minetest.register_node("vallee_des_roses:brittle_poppy", {
    description = "A Brittle Poppy Flower",
    drawtype = "plantlike",
    -- Only one texture used
    tiles = {"vallee_des_roses_brittle_poppy.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -6 / 16, 6 / 16, 0.5, 6 / 16},
    },
    walkable = false,
	buildable_to = true,
})

-- Hyacinth Flower
minetest.register_node("vallee_des_roses:hyacinth", {
    description = "A Hyacinth Flower",
    drawtype = "plantlike",
    -- Only one texture used
    tiles = {"vallee_des_roses_hyacinth.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, -1 / 16, 4 / 16},
    },
    groups = {snappy=3,oddly_breakable_by_hand=3},
    walkable = false,
	buildable_to = true,
})

-- Uncooked Apple Pie Item
minetest.register_craftitem("vallee_des_roses:uncooked_apple_pie", {
    description = "Uncooked Apple Pie",
    inventory_image = "vallee_des_roses_uncooked_apple_pie.png",
})

-- Cooked Apple Pie Item
minetest.register_craftitem("vallee_des_roses:apple_pie", {
    description = "Apple Pie",
    on_use = minetest.item_eat(8),
    inventory_image = "vallee_des_roses_apple_pie.png",

})

-- Uncooked Apple Pie Craft
minetest.register_craft({    
type = "shapeless",
output = "vallee_des_roses:uncooked_apple_pie",
recipe = {
    "default:apple",
    "default:wheat",
}
})

-- Cook Uncooked Apple Pie
minetest.register_craft({
    type = "cooking",
    output = "vallee_des_roses:apple_pie",
    recipe = "vallee_des_roses:uncooked_apple_pie",
    cooktime = 5,
})

-- Adds Ruby Item
minetest.register_craftitem("vallee_des_roses:ruby",{
description = "A Shiny Ruby",
inventory_image = "vallee_des_roses_ruby.png",
})

-- Adds Ruby Lump
minetest.register_craftitem("vallee_des_roses:ruby_lump",{
    description = "A lump of Ruby",
    inventory_image = "vallee_des_roses_ruby_lump.png",
    })

-- Adds Ruby Ore
minetest.register_node("vallee_des_roses:ruby_ore", {
	description = "Ruby Ore",
	tiles = {"default_stone.png^vallee_des_roses_ruby_ore.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "vallee_des_roses:ruby_lump"
})

-- Adds Smelt Recipe
minetest.register_craft({
    type = "cooking",
    output = "vallee_des_roses:ruby",
    recipe = "vallee_des_roses:ruby_lump",
    cooktime = 3,
})

-- Adds Ruby as an Ore for MapGen
minetest.register_ore({
	ore_type = "scatter",
	ore = "vallee_des_roses:ruby_ore",
	wherein = "default:stone",
	clust_scarcity = 11 * 11 * 11,
	clust_num_ores = 4,
	clust_size = 11,
	y_min = -31000,
	y_max = -2
})

-- Adds Ruby Tools

minetest.register_tool("vallee_des_roses:ruby_pick", {
	description = "Ruby Pickaxe",
	inventory_image = "vallee_des_roses_ruby_pick.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 4},
		groupcaps = {
			cracky = {
				times = {[1] = 2.60, [2] = 1.00, [3] = 0.60}, uses = 300, maxlevel = 1}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_shovel", {
	description = "Ruby Shovel",
	inventory_image = "vallee_des_roses_ruby_shovel.png",
	wield_image = "vallee_des_roses_ruby_shovel.png^[transformR90",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 3},
		groupcaps = {
			crumbly = {
				times = {[1] = 1.10, [2] = 0.40, [3] = 0.25}, uses = 100, maxlevel = 1}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_axe", {
	description = "Ruby Axe",
	inventory_image = "vallee_des_roses_ruby_axe.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 5},
		groupcaps = {
			fleshy = {times = {[2] = 1.10, [3] = 0.60}, uses = 100, maxlevel = 1},
			choppy = {
				times = {[1] = 2.50, [2] = 0.80, [3] = 0.50}, uses = 100, maxlevel = 1}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_sword", {
	description = "Ruby Sword",
	inventory_image = "vallee_des_roses_ruby_sword.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 8},
		groupcaps = {
			fleshy = {times = {[2] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			snappy = {times = {[2] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			choppy = {times = {[3] = 0.80}, uses = 100, maxlevel = 0}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_hoe", {
	description = "Ruby Hoe",
	inventory_image = "vallee_des_roses_ruby_hoe.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 3},
		groupcaps = {
			fleshy = {times = {[1] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			snappy = {times = {[3] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			choppy = {times = {[1] = 0.80}, uses = 100, maxlevel = 0}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_scythe", {
	description = "Ruby Scythe",
	inventory_image = "vallee_des_roses_ruby_scythe.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 10},
		groupcaps = {
			fleshy = {times = {[3] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			snappy = {times = {[3] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			choppy = {times = {[1] = 0.80}, uses = 100, maxlevel = 0}
		}
	}
})

-- Adds Ruby Craft Recipes

minetest.register_craft({
    type = "shaped",
    output = "vallee_des_roses:ruby_pick",
    recipe = {
        {"vallee_des_roses:ruby", "vallee_des_roses:ruby", "vallee_des_roses:ruby",},
        {"", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({
    type = "shaped",
    output = "vallee_des_roses:ruby_axe",
    recipe = {
        {"vallee_des_roses:ruby", "vallee_des_roses:ruby", "",},
        {"vallee_des_roses:ruby", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({
    type = "shaped",
    output = "vallee_des_roses:ruby_shovel",
    recipe = {
        {"", "vallee_des_roses:ruby", "",},
        {"", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({
    type = "shaped",
    output = "vallee_des_roses:ruby_hoe",
    recipe = {
        {"vallee_des_roses:ruby", "vallee_des_roses:ruby", "",},
        {"", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({
    type = "shaped",
    output = "vallee_des_roses:ruby_sword",
    recipe = {
        {"", "vallee_des_roses:ruby", "",},
        {"", "vallee_des_roses:ruby", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({
    type = "shapeless",
    output = "vallee_des_roses:ruby_scythe",
    recipe = {"vallee_des_roses:ruby_hoe", "default:stone"},
})