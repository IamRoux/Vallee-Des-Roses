--[[
_      __    _ _             ____              ____                     
\ \   / /_ _| | | ___  ___  |  _ \  ___  ___  |  _ \ ___  ___  ___  ___ 
 \ \ / / _` | | |/ _ \/ _ \ | | | |/ _ \/ __| | |_) / _ \/ __|/ _ \/ __|
  \ V / (_| | | |  __/  __/ | |_| |  __/\__ \ |  _ < (_) \__ \  __/\__ \
   \_/ \__,_|_|_|\___|\___| |____/ \___||___/ |_| \_\___/|___/\___||___/
                             (Version - v1.1)                                   



 Vallee Des Roses Mod, adds flowers, cottage style glass, ruby ores and tools
and more food types. Add to your minetest mod folder ~/.minetest/mods ]]--

-- Cottage Style Glass
minetest.register_node("vallee_des_roses:cottage_style_glass", {
    description = "Cottage Style Glass",
    drawtype = "glasslike",
    tiles = {"vallee_des_roses_cottageglass.png"},
    paramtype = "light",
    is_ground_content = false,
    sunlight_propagates = true,
    sounds = default.node_sound_glass_defaults(),
    groups = {cracky=3,oddly_breakable_by_hand=3},

})

-- Adds Chisel Item
minetest.register_craftitem("vallee_des_roses:chisel",{
    description = "Chisel",
    inventory_image = "vallee_des_roses_chisel.png",
    })


-- Chisel Craft Recipe
minetest.register_craft({ 
    type = "shapeless",
    output = "vallee_des_roses:chisel",
    recipe = {"default:stick", "default:stone"},
})

-- Cottage Sytle Glass Recipe
minetest.register_craft({ 
    type = "shapeless",
    output = "vallee_des_roses:cottage_style_glass",
    recipe = {"default:glass", "vallee_des_roses:chisel"},
    replacements = {{"vallee_des_roses:chisel", "vallee_des_roses:chisel"}},
})

-- Charcoal Item
minetest.register_craftitem("vallee_des_roses:charcoal",{
    description = "Charcoal",
    inventory_image = "vallee_des_roses_charcoal.png",
    })

-- Charcoal to Fuel Modif
minetest.register_craft({
	type = "fuel",
	recipe = "vallee_des_roses:charcoal",
	burntime = 8,
})

-- Charcoal smelt, adds it for all log types
minetest.register_craft({ -- Apple Tree
    type = "cooking",
    output = "vallee_des_roses:charcoal",
    recipe = "default:tree",
    cooktime = 3,
})

minetest.register_craft({ -- Aspen Tree
    type = "cooking",
    output = "vallee_des_roses:charcoal",
    recipe = "default:aspen_tree",
    cooktime = 3,
})

minetest.register_craft({ -- Acacia Tree
    type = "cooking",
    output = "vallee_des_roses:charcoal",
    recipe = "default:acacia_tree",
    cooktime = 3,
})

minetest.register_craft({ -- Pine Tree
    type = "cooking",
    output = "vallee_des_roses:charcoal",
    recipe = "default:pine_tree",
    cooktime = 3,
})

minetest.register_craft({ -- Jungle Tree
    type = "cooking",
    output = "vallee_des_roses:charcoal",
    recipe = "default:jungletree",
    cooktime = 3,
})


-- Marigold Flower
minetest.register_node("vallee_des_roses:marigold", {
    description = "A Marigold Flower",
    drawtype = "plantlike",

    -- Only one texture used
    tiles = {"vallee_des_roses_marigold.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -6 / 16, 6 / 16, 0.5, 6 / 16},
    },
    groups = {snappy=3,oddly_breakable_by_hand=3},
    walkable = false,
	buildable_to = true,
    drop = "vallee_des_roses:marigold"
})

-- Buttercup Flower
minetest.register_node("vallee_des_roses:buttercup", {
    description = "A Buttercup Flower",
    drawtype = "plantlike",
    -- Only one texture used
    tiles = {"vallee_des_roses_buttercup.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, -1 / 16, 4 / 16},
    },
    groups = {snappy=3,oddly_breakable_by_hand=3},
    walkable = false,
	buildable_to = true,
    drop = "vallee_des_roses:buttercup"
})

-- Brittle Poppy
-- (Note: It's meant to be unbreakable, its a joke, not a bug)
minetest.register_node("vallee_des_roses:brittle_poppy", {
    description = "A Brittle Poppy Flower",
    drawtype = "plantlike",
    -- Only one texture used
    tiles = {"vallee_des_roses_brittle_poppy.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -6 / 16, 6 / 16, 0.5, 6 / 16},
    },
    walkable = false,
	buildable_to = true,
})

-- Hyacinth Flower
minetest.register_node("vallee_des_roses:hyacinth", {
    description = "A Hyacinth Flower",
    drawtype = "plantlike",
    -- Only one texture used
    tiles = {"vallee_des_roses_hyacinth.png"},

    selection_box = {
        type = "fixed",
        fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, -1 / 16, 4 / 16},
    },
    groups = {snappy=3,oddly_breakable_by_hand=3},
    walkable = false,
	buildable_to = true,
    drop = "vallee_des_roses:hyacinth"
})

-- Makes Flowers Decorations
minetest.register_decoration({ -- Marigold
    deco_type = "simple",
    place_on = {"base:dirt_with_grass"},
    sidelen = 16,
    fill_ratio = 0.07,
    biomes = {"grasslands", "coniferous_forest", "deciduous_forest"},
    y_max = 200,
    y_min = 1,
    decoration = "vallee_des_roses:marigold",
})

minetest.register_decoration({ -- Buttercup
    deco_type = "simple",
    place_on = {"base:dirt_with_grass"},
    sidelen = 16,
    fill_ratio = 0.06,
    biomes = {"grasslands", "coniferous_forest", "deciduous_forest"},
    y_max = 200,
    y_min = 1,
    decoration = "vallee_des_roses:buttercup",
})

minetest.register_decoration({ -- Hyacinth
    deco_type = "simple",
    place_on = {"base:dirt_with_grass", "base:dirt_with_snow", "base:dirt_with_coniferous_litter"},
    sidelen = 16,
    fill_ratio = 0.1,
    biomes = {"grassy_plains", "snowy_grassland", "taiga"},
    y_max = 200,
    y_min = 1,
    decoration = "vallee_des_roses:hyacinth",
})



-- Uncooked Apple Pie Item
minetest.register_craftitem("vallee_des_roses:uncooked_apple_pie", {
    description = "Uncooked Apple Pie",
    inventory_image = "vallee_des_roses_uncooked_apple_pie.png",
})

-- Cooked Apple Pie Item
minetest.register_craftitem("vallee_des_roses:apple_pie", {
    description = "Apple Pie",
    on_use = minetest.item_eat(8),
    inventory_image = "vallee_des_roses_apple_pie.png",

})

-- Uncooked Apple Pie Craft
minetest.register_craft({    
type = "shapeless",
output = "vallee_des_roses:uncooked_apple_pie",
recipe = {
    "default:apple",
    "default:wheat",
}
})

-- Cook Uncooked Apple Pie
minetest.register_craft({
    type = "cooking",
    output = "vallee_des_roses:apple_pie",
    recipe = "vallee_des_roses:uncooked_apple_pie",
    cooktime = 5,
})

-- Adds Ruby Item
minetest.register_craftitem("vallee_des_roses:ruby",{
description = "A Shiny Ruby",
inventory_image = "vallee_des_roses_ruby.png",
})

-- Adds Ruby Lump
minetest.register_craftitem("vallee_des_roses:ruby_lump",{
    description = "A lump of Ruby",
    inventory_image = "vallee_des_roses_ruby_lump.png",
    })

-- Adds Ruby Ore
minetest.register_node("vallee_des_roses:ruby_ore", {
	description = "Ruby Ore",
	tiles = {"default_stone.png^vallee_des_roses_ruby_ore.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "vallee_des_roses:ruby_lump"
})

-- Adds Smelt Recipe
minetest.register_craft({
    type = "cooking",
    output = "vallee_des_roses:ruby",
    recipe = "vallee_des_roses:ruby_lump",
    cooktime = 3,
})

-- Adds Ruby as an Ore for MapGen
minetest.register_ore({
	ore_type = "scatter",
	ore = "vallee_des_roses:ruby_ore",
	wherein = "default:stone",
	clust_scarcity = 11 * 11 * 11,
	clust_num_ores = 4,
	clust_size = 11,
	y_min = -31000,
	y_max = -2
})

-- Adds Ruby Tools

minetest.register_tool("vallee_des_roses:ruby_pick", { -- Ruby Pickaxe
	description = "Ruby Pickaxe",
	inventory_image = "vallee_des_roses_ruby_pick.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 4},
		groupcaps = {
			cracky = {
				times = {[1] = 2.60, [2] = 1.00, [3] = 0.60}, uses = 400, maxlevel = 1}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_shovel", { -- Ruby Shovel
	description = "Ruby Shovel",
	inventory_image = "vallee_des_roses_ruby_shovel.png",
	wield_image = "vallee_des_roses_ruby_shovel.png^[transformR90",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 3},
		groupcaps = {
			crumbly = {
				times = {[1] = 1.10, [2] = 0.40, [3] = 0.25}, uses = 200, maxlevel = 1}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_axe", { -- Ruby Axe
	description = "Ruby Axe",
	inventory_image = "vallee_des_roses_ruby_axe.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 5},
		groupcaps = {
			fleshy = {times = {[2] = 1.10, [3] = 0.60}, uses = 100, maxlevel = 1},
			choppy = {
				times = {[1] = 2.50, [2] = 0.80, [3] = 0.50}, uses = 100, maxlevel = 1}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_sword", { -- Ruby Sword
	description = "Ruby Sword",
	inventory_image = "vallee_des_roses_ruby_sword.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 8},
		groupcaps = {
			fleshy = {times = {[2] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			snappy = {times = {[2] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			choppy = {times = {[3] = 0.80}, uses = 100, maxlevel = 0}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_hoe", { -- Ruby Hoe
	description = "Ruby Hoe",
	inventory_image = "vallee_des_roses_ruby_hoe.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 3},
		groupcaps = {
			fleshy = {times = {[1] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			snappy = {times = {[3] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			choppy = {times = {[1] = 0.80}, uses = 100, maxlevel = 0}
		}
	}
})

minetest.register_tool("vallee_des_roses:ruby_scythe", { -- Ruby Scythe
	description = "Ruby Scythe",
	inventory_image = "vallee_des_roses_ruby_scythe.png",
	sound = {breaks = "default_tool_breaks"},
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 3,
		damage_groups = {fleshy = 10},
		groupcaps = {
			fleshy = {times = {[3] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			snappy = {times = {[3] = 0.70, [3] = 0.30}, uses = 100, maxlevel = 1},
			choppy = {times = {[1] = 0.80}, uses = 100, maxlevel = 0}
		}
	}
})

-- Adds Ruby Craft Recipes

minetest.register_craft({ -- Ruby Pickaxe Recipe
    type = "shaped",
    output = "vallee_des_roses:ruby_pick",
    recipe = {
        {"vallee_des_roses:ruby", "vallee_des_roses:ruby", "vallee_des_roses:ruby",},
        {"", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({ -- Ruby Axe Recipe
    type = "shaped",
    output = "vallee_des_roses:ruby_axe",
    recipe = {
        {"vallee_des_roses:ruby", "vallee_des_roses:ruby", "",},
        {"vallee_des_roses:ruby", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({ -- Ruby Shovel Recipe
    type = "shaped",
    output = "vallee_des_roses:ruby_shovel",
    recipe = {
        {"", "vallee_des_roses:ruby", "",},
        {"", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({ -- Ruby Hoe Recipe
    type = "shaped",
    output = "vallee_des_roses:ruby_hoe",
    recipe = {
        {"vallee_des_roses:ruby", "vallee_des_roses:ruby", "",},
        {"", "group:stick", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({ -- Ruby Sword Recipe
    type = "shaped",
    output = "vallee_des_roses:ruby_sword",
    recipe = {
        {"", "vallee_des_roses:ruby", "",},
        {"", "vallee_des_roses:ruby", ""},
        {"", "group:stick", ""}
    }
})

minetest.register_craft({ -- Ruby Scythe Recipe
    type = "shapeless",
    output = "vallee_des_roses:ruby_scythe",
    recipe = {"vallee_des_roses:ruby_hoe", "default:stone"},
})
